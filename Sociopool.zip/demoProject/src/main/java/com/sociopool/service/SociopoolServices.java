package com.sociopool.service;

import com.sociopool.dto.SociopoolDistanceDto;
import com.sociopool.dto.SociopoolSearchDto;
import com.sociopool.dto.SociopoolUserDto;
import com.sociopool.model.SociopoolDistanceModel;
import com.sociopool.model.SociopoolUserModel;

/*
 * @author Vaibhav
 */
public interface SociopoolServices {

	public void addUser(SociopoolUserDto sociopoolUserDto);
	public void addDistaceCovered(SociopoolDistanceDto sociopoolDistanceDto);
	public long distanceBetweenTime(SociopoolSearchDto sociopoolsearchDto);
}