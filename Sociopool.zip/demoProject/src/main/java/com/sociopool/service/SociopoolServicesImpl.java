package com.sociopool.service;

import java.util.List;
import java.util.regex.Pattern;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.bson.diagnostics.Logger;
import org.bson.diagnostics.Loggers;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;

import com.sociopool.constant.SociopoolPromptMessage;
import com.sociopool.exception.GenericException;
import com.sociopool.model.SociopoolUserModel;
import com.sociopool.repository.SociopoolDistanceRepository;
import com.sociopool.repository.SociopoolUserRepository;
import com.sociopool.dto.SociopoolDistanceDto;
import com.sociopool.dto.SociopoolSearchDto;
import com.sociopool.dto.SociopoolUserDto;
import com.sociopool.model.SociopoolDistanceModel;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



/**
 * @author vaibhav
 *
 */


@Service
public class SociopoolServicesImpl implements SociopoolServices{
	
	@Autowired
	SociopoolServices sociopoolservices;
	
	@Autowired
	private MongoTemplate mongoOperations;
	
	@Autowired
	SociopoolDistanceRepository sociopoolDistanceRepository;
	
	@Autowired
	SociopoolUserRepository sociopoolUserRepository;
	
	private final Logger LOGGER = Loggers.getLogger(this.getClass().getName());

	@Override
	public void addUser(SociopoolUserDto sociopoolUserDto) {
		// TODO Auto-generated method stub
		if (org.apache.commons.lang.StringUtils.isBlank(sociopoolUserDto.getUserEmail())
                || org.apache.commons.lang.StringUtils.isBlank(sociopoolUserDto.getUserName())
                || org.apache.commons.lang.StringUtils.isBlank(sociopoolUserDto.getUserContact())
                || sociopoolUserDto.getUserName() == null
                || sociopoolUserDto.getUserEmail() == null
                || sociopoolUserDto.getUserContact() == null)
            throw new GenericException(SociopoolPromptMessage.INCORRECT_PARAMS);

        Query query = new Query();
        query.addCriteria(Criteria.where("userEmail").is(sociopoolUserDto.getUserEmail()));
        List<SociopoolUserModel> user = mongoOperations.find(query, SociopoolUserModel.class);
        if (user.size() != 0)
            throw new GenericException(SociopoolPromptMessage.USER_EXISTS);

        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." +
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        if (!pattern.matcher(sociopoolUserDto.getUserEmail()).matches())
            throw new GenericException(SociopoolPromptMessage.INCORRECT_MAIL);
        LOGGER.info("Email validated");
        SociopoolUserModel sociopoolUserModel = SociopoolUserModel.builder().userName(sociopoolUserDto.getUserName())
                .userEmail(sociopoolUserDto.getUserEmail())
                .userCreatedAt(System.currentTimeMillis()).build();
        sociopoolUserRepository.save(sociopoolUserModel);
	}

	@Override
	public void addDistaceCovered(SociopoolDistanceDto sociopoolDistanceDto) {
		
		if (org.apache.commons.lang.StringUtils.isBlank(sociopoolDistanceDto.getUserId())
                || sociopoolDistanceDto.getDate() == null
                || sociopoolDistanceDto.getTime() == null
                || sociopoolDistanceDto.getDistanceCovered() == null
                || sociopoolDistanceDto.getStartTime()==null
                || sociopoolDistanceDto.getEndTime()==null)
            throw new GenericException(SociopoolPromptMessage.INCORRECT_PARAMS);
		
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(new ObjectId(sociopoolDistanceDto.getUserId())));
		List<SociopoolUserModel> user = mongoOperations.find(query, SociopoolUserModel.class);
		
		//List<SociopoolUserModel> user = mongoOperations.find(sociopoolDistanceDto.getUserId(), SociopoolUserModel.class);
		if(user.size()==0) {
			throw new GenericException(SociopoolPromptMessage.INVALID_USER_ID);
		}
		
		SociopoolDistanceModel sociopoolDistanceModel = SociopoolDistanceModel.builder().userId(sociopoolDistanceDto.getUserId())
				.date(sociopoolDistanceDto.getDate())
				.time(sociopoolDistanceDto.getTime())
				.distanceCovered(sociopoolDistanceDto.getDistanceCovered())
				.startTime(sociopoolDistanceDto.getStartTime())
				.endTime(sociopoolDistanceDto.getEndTime()).build();
		sociopoolDistanceRepository.save(sociopoolDistanceModel);
	}

	@Override
	public long distanceBetweenTime(SociopoolSearchDto sociopoolsearchDto) {
		// TODO Auto-generated method stub
		long totalDistanceTravelled = 0;
		if (org.apache.commons.lang.StringUtils.isBlank(sociopoolsearchDto.getUserId())
				|| sociopoolsearchDto.getUserId() == null
				|| sociopoolsearchDto.getStartTime() == null
                || sociopoolsearchDto.getEndTime() == null) {
			throw new GenericException(SociopoolPromptMessage.INCORRECT_PARAMS);
		}
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(new ObjectId(sociopoolsearchDto.getUserId())));
		List<SociopoolUserModel> user = mongoOperations.find(query, SociopoolUserModel.class);
		if(user.size()==0) {
			throw new GenericException(SociopoolPromptMessage.INVALID_USER_ID);
		}
		Query searchQuery = new Query();
		query.addCriteria(Criteria.where("userId").is(sociopoolsearchDto.getUserId()));
		query.addCriteria(Criteria.where("startTime").gte(sociopoolsearchDto.getStartTime()));
		query.addCriteria(Criteria.where("endTime").lte(sociopoolsearchDto.getEndTime()));
		
		List<SociopoolDistanceModel> distances = mongoOperations.find(searchQuery,SociopoolDistanceModel.class);
		for(SociopoolDistanceModel sdm : distances) {
			totalDistanceTravelled += sdm.getDistanceCovered();
		}
		return totalDistanceTravelled;
	}

}
