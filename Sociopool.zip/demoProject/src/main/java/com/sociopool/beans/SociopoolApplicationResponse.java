package com.sociopool.beans;

import org.springframework.http.HttpStatus;
import lombok.Data;
/*
 *@author Vaibhav
  */


@Data 
public class SociopoolApplicationResponse {
	
	private Object data;
    private boolean success;
    private int httpStatus;


    public static SociopoolApplicationResponse success(final Object data) {
        final SociopoolApplicationResponse response = new SociopoolApplicationResponse();
        response.setData(data);
        response.setSuccess(true);
        response.setHttpStatus(HttpStatus.OK.value());

        return response;
    }

	public static SociopoolApplicationResponse success() {
        final SociopoolApplicationResponse response = new SociopoolApplicationResponse();
        response.setSuccess(true);
        response.setHttpStatus(HttpStatus.OK.value());
        return response;
    }



}
