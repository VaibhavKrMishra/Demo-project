package com.sociopool.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.sociopool.model.SociopoolUserModel;

/*
 * @author Vaibhav
 * */

@Repository
public interface SociopoolUserRepository extends MongoRepository<SociopoolUserModel, String>{

}
