package com.sociopool.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * @author vaibhav
 *
 */

import com.sociopool.model.SociopoolDistanceModel;


@Repository
public interface SociopoolDistanceRepository extends MongoRepository<SociopoolDistanceModel, String>{

}
