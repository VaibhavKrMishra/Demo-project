package com.sociopool.controller;

import java.util.Date;
import java.util.List;
import com.sociopool.constant.SociopoolPromptMessage;
import com.sociopool.dto.SociopoolDistanceDto;
import com.sociopool.dto.SociopoolSearchDto;
import com.sociopool.dto.SociopoolUserDto;
import com.sociopool.model.SociopoolUserModel;
import com.sociopool.repository.SociopoolDistanceRepository;
import com.sociopool.repository.SociopoolUserRepository;
import com.sociopool.service.SociopoolServices;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;

import com.sociopool.beans.SociopoolApplicationResponse;
import com.sociopool.exception.GenericException;
import javax.validation.Valid;

/**
 * @author Vaibhav
 */
@RestController
@CrossOrigin
@RequestMapping("/sociopool")
public class SociopoolController {

    
    @Autowired
    private SociopoolUserRepository sociopoolUserRepository;
    
    @Autowired
    private SociopoolDistanceRepository sociopoolDistanceRepository;

    @Autowired
    private MongoTemplate mongoOperations;

    @Autowired
    private SociopoolServices sociopoolService;


    //adding single/multiple users
    @PostMapping("/addUsers")
    public SociopoolApplicationResponse saveUser(@RequestBody List<SociopoolUserDto> sociopoolUserDtos) {
        for(SociopoolUserDto sociopoolUserDto:sociopoolUserDtos)
            sociopoolService.addUser(sociopoolUserDto);
        return SociopoolApplicationResponse.success(SociopoolPromptMessage.USER_ADDED_SUCCESSFULLY);
    }
    
    @PostMapping("/AddDistanceTravelled")
    public SociopoolApplicationResponse addDistanceTravelled(@RequestBody SociopoolDistanceDto sociopoolDistanceDto) {
    	sociopoolService.addDistaceCovered(sociopoolDistanceDto);
    	return SociopoolApplicationResponse.success(SociopoolPromptMessage.DISTANCE_ENTRY_SUCCESSFUL);
    }
    
    @PostMapping("/DistanceBetweenTime")
    public SociopoolApplicationResponse distanceBetweenTime(@RequestBody SociopoolSearchDto sociopoolSearchDto) {
    	return SociopoolApplicationResponse.success(sociopoolService.distanceBetweenTime(sociopoolSearchDto));
    }
    
}
