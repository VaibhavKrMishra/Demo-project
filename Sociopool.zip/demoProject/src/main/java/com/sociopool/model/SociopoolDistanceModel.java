package com.sociopool.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



/**
 * @author vaibhav
 *
 */


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data


@Document(collection = "travelEntry")
public class SociopoolDistanceModel {
	@Id
    private String id;
    private String userId;
    private Date date;
    private Long time;
    private Long distanceCovered;
    private Long startTime;
    private Long endTime;

}
