package com.sociopool.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author vaibhav
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data


@Document(collection = "user")
public class SociopoolUserModel {

    @Id
    private String id;
    private String userName;
    private String userEmail;
    private String userContact;
    private Long userCreatedAt;

}
