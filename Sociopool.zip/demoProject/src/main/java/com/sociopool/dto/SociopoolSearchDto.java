package com.sociopool.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



/**
 * @author vaibhav
 *
 */


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data

public class SociopoolSearchDto {
	public String userId;
	public Long startTime;
	public Long endTime;
}
