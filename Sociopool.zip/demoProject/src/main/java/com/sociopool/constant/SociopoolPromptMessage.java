package com.sociopool.constant;

/**
 * @author Vaibhav
 */


public final class SociopoolPromptMessage {

    public static final String INCORRECT_PARAMS = "Incorrect Params ";
    public static final String SEARCH_EMPTY = "Search Unsuccessfull ";
    public static final String INCORRECT_MAIL = "Incorrect Email ";
    public static final String INVALID_USER_ID = "Invalid User Id or User not Present ";
    public static final String USER_EXISTS = "User Already Exists ";
    public static final String USER_ADDED_SUCCESSFULLY = "User Added Successfully ";
    public static final String WITH_ID = "with ID: ";
    public static final String AT_DELIMITER = " at ";
    public static final String DISTANCE_ENTRY_SUCCESSFUL = "Distance Entry Successful";


}
